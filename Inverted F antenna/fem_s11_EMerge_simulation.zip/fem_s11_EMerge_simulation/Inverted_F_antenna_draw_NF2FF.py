## EMerge simulation - S11
#
#
import emerge as em
import numpy as np
from emerge.plot import smith, plot_sp

from emerge.plot import plot_ff, plot_ff_polar  #added for far field plot
import os

simulationObj = em.Simulation("Inverted_F_antenna.FCStd", load_file=True)
simulationResult = simulationObj.data.mw

#######################################################################################################################################
# EXCITATION basic
#######################################################################################################################################
fmin = 2.0*1000000000.0
fmax = 3.0*1000000000.0
resolution = 0.3
npoints = 7
simulationObj.mw.set_frequency_range(fmin, fmax, npoints)
simulationObj.mw.set_resolution(resolution)

freqs = simulationResult.scalar.grid.freq
freq_dense = np.linspace(fmin, fmax, 101)

S11 = simulationResult.scalar.grid.model_S(1, 1, freq_dense)  # reflection coefficient
plot_sp(freq_dense, S11)  # plot return loss in dB
smith(S11, f=freq_dense, labels='S11')  # Smith chart of S11


#######################################################################################################################################
# FAR FIELD PLOT
#######################################################################################################################################
mm = 0.001
currDir = os.getcwd()


#######################################################################################################################################
# MATERIALS AND GEOMETRY
#######################################################################################################################################
materialList = {}

## MATERIAL - FR4
materialList['FR4'] = em.Material(name='FR4', er=4.2, ur=1)
materialList['FR4'].color = '#ffab00'
materialList['FR4'].opacity = 1.0

stepObjectGroup = em.geo.step.STEPItems(name='substrate', filename=os.path.join(currDir,'substrate_gen_model.step'), unit=mm)
for geoObj in stepObjectGroup.objects:
	geoObj.prio_set(9700)
	geoObj.set_material(materialList['FR4'])

## MATERIAL - PEC
materialList['PEC'] = em.lib.PEC
materialList['PEC'].color = '#adb5bd'
materialList['PEC'].opacity = 1.0

stepObjectGroup = em.geo.step.STEPItems(name='top gnd', filename=os.path.join(currDir,'top gnd_gen_model.step'), unit=mm)
for geoObj in stepObjectGroup.objects:
	geoObj.prio_set(9800)
	geoObj.set_material(materialList['PEC'])
materialList['PEC'].color = '#adb5bd'
materialList['PEC'].opacity = 1.0

stepObjectGroup = em.geo.step.STEPItems(name='antenna', filename=os.path.join(currDir,'antenna_gen_model.step'), unit=mm)
for geoObj in stepObjectGroup.objects:
	geoObj.prio_set(9900)
	geoObj.set_material(materialList['PEC'])

## MATERIAL - air
materialList['air'] = em.Material(name='air', er=1, ur=1)


# Imported objects used as boundary conditions
#

position = (40.0, -37.0, 0.0)
position = tuple([x*mm for x in position])
newSphereObj = em.geo.Sphere(radius=180.0*mm, position=position)
newSphereObj.give_name('airbox')
newSphereObj.name = 'airbox'
newSphereObj.prio_set(9600)

#######################################################################################################################################
#   ADD BOUNDARY SELECTION SAME AS SIMULATION FILE
#######################################################################################################################################

boundary_selection = None
for geometryObj in simulationObj.state.manager.geometry_list[simulationObj.modelname].values():
	if geometryObj.name == 'airbox' or geometryObj.name.startswith('airbox'):
		boundary_selection = geometryObj.boundary()

simulationObj.mw.bc.AbsorbingBoundary(boundary_selection)


# add model files into display
for geoObj in simulationObj.state.manager.geometry_list[simulationObj.modelname].values():
	simulationObj.display.add_object(geoObj)

# display far field
field = simulationResult.field.find(freq=2.45e9)
ff3d = field.farfield_3d(boundary_selection, origin=position)
simulationObj.display.add_field(ff3d.surfplot('normE','abs',True, rmax=40*mm, offset=(position[0], position[1], position[2]+10*mm)))
simulationObj.display.show()
